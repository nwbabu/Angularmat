export class login
{
   public Login:string;
   public password:string;
}