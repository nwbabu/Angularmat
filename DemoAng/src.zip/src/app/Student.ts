 export interface Student
 {
     stid:number;
     stName:string;
     stCourse:string;
 }
