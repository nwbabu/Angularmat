export  interface login
{
   loginId:string;
   loginPassword:string;
}